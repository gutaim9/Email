import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const FeatureCard = ({ icon, title, description, delay = 0 }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay }}
      className="frosted-glass p-6 rounded-xl scale-on-hover"
    >
      <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-[#00F5A0] to-[#00D9F5] flex items-center justify-center mb-4 rotate-icon">
        {icon}
      </div>
      
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      
      <p className="text-white/70">{description}</p>
    </motion.div>
  );
};

export default FeatureCard;