import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import TestimonialCard from './TestimonialCard';

const Testimonials = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [currentIndex, setCurrentIndex] = useState(0);
  const testimonialRef = useRef(null);
  
  const testimonials = [
    {
      quote: "4HIGH has completely transformed our email marketing. We've seen a 43% increase in open rates and a 27% boost in conversions since implementing their AI-powered automation.",
      name: "Sarah Johnson",
      position: "Marketing Director",
      company: "TechGrowth"
    },
    {
      quote: "The smart scheduling feature alone saved our team over 20 hours per week. The personalization capabilities are unlike anything I've seen before.",
      name: "David Chen",
      position: "Digital Marketing Lead",
      company: "Shopverse"
    },
    {
      quote: "We were able to increase our email ROI by 52% in just three months. The analytics provide insights we never had access to before.",
      name: "Amelia Rodriguez",
      position: "CMO",
      company: "NextLevel Brands"
    },
    {
      quote: "The setup was incredibly easy, and the support team was there every step of the way. Now our emails perform better than ever with minimal effort from our team.",
      name: "Michael Thompson",
      position: "Growth Manager",
      company: "EcoSolutions"
    }
  ];

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  // Auto-scroll testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      handleNext();
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  // Determine visible testimonials based on screen size
  const getVisibleCount = () => {
    if (typeof window !== 'undefined') {
      if (window.innerWidth < 768) return 1;
      if (window.innerWidth < 1024) return 2;
      return 3;
    }
    return 3;
  };

  const [visibleCount, setVisibleCount] = useState(3);

  useEffect(() => {
    const handleResize = () => {
      setVisibleCount(getVisibleCount());
    };
    
    handleResize();
    window.addEventListener('resize', handleResize);
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Get visible testimonials
  const visibleTestimonials = [];
  for (let i = 0; i < visibleCount; i++) {
    const index = (currentIndex + i) % testimonials.length;
    visibleTestimonials.push(testimonials[index]);
  }

  return (
    <section className="section-padding relative bg-black overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            What Our <span className="gradient-text">Customers Say</span>
          </h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            Join thousands of marketers who have transformed their email campaigns with 4HIGH.
          </p>
        </motion.div>

        <div className="relative">
          <div 
            ref={testimonialRef}
            className="flex overflow-hidden"
          >
            <motion.div
              animate={{ x: `-${currentIndex * 100 / visibleCount}%` }}
              transition={{ type: 'spring', stiffness: 120, damping: 20 }}
              className="flex w-full"
            >
              {testimonials.map((testimonial, index) => (
                <div 
                  key={index} 
                  className={`w-full md:w-1/${visibleCount} flex-shrink-0`}
                >
                  <TestimonialCard {...testimonial} />
                </div>
              ))}
            </motion.div>
          </div>

          <div className="flex justify-center mt-8 gap-4">
            <motion.button
              onClick={handlePrev}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </motion.button>
            
            <motion.button
              onClick={handleNext}
              className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </motion.button>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-16 lg:mt-24 flex flex-wrap justify-center gap-8 md:gap-16"
        >
          {['Adobe', 'Shopify', 'Slack', 'Dropbox', 'Notion'].map((company, index) => (
            <div key={index} className="logo-grayscale">
              <span className="text-xl font-semibold text-white/40">{company}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;