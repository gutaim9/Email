import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import ParticleBackground from './ParticleBackground';

const CallToAction = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // Countdown timer
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    // Set end date to 7 days from now
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 7);
    
    const timer = setInterval(() => {
      const now = new Date();
      const difference = endDate - now;
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      } else {
        clearInterval(timer);
      }
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-black via-black/90 to-[#001a12] z-0"></div>
      <ParticleBackground count={40} speed={0.2} />
      
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
        className="container mx-auto px-6 relative z-10"
      >
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Ready to <span className="gradient-text">Revolutionize</span> Your Email Marketing?
          </h2>
          
          <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            Join thousands of marketers who have transformed their email campaigns with 4HIGH. Start your free trial today.
          </p>

          <div className="mb-8">
            <p className="text-white/60 mb-4">Limited time offer - Get 25% off your first 3 months</p>
            
            <div className="flex justify-center gap-4">
              {Object.entries(timeLeft).map(([unit, value]) => (
                <div key={unit} className="frosted-glass p-3 rounded-lg w-16 md:w-20 text-center">
                  <div className="text-xl md:text-2xl font-bold gradient-text">{value}</div>
                  <div className="text-xs md:text-sm text-white/60">{unit}</div>
                </div>
              ))}
            </div>
          </div>
          
          <motion.a
            href="#trial"
            className="gradient-button text-lg px-10 py-4 inline-block"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            Start Free Trial
          </motion.a>
          
          <p className="mt-4 text-white/60">No credit card required. 14-day free trial.</p>
        </div>
      </motion.div>
    </section>
  );
};

export default CallToAction;