import React from 'react';

const Logo = ({ className }) => {
  return (
    <div className="flex items-center">
      <img 
        src="/src/assets/file_00000000d19461f6bfa17f7fd2585e80-removebg-preview.png" 
        alt="4" 
        className={`${className} mr-0.5`}
      />
      <span 
        className="gradient-text font-bold tracking-wide"
        style={{
          fontFamily: 'Inter',
          fontSize: 'calc(var(--logo-height, 2rem) * 0.85)',
          height: 'var(--logo-height, 2rem)',
          lineHeight: 'var(--logo-height, 2rem)',
          letterSpacing: '0.02em'
        }}
      >
        HIGH
      </span>
    </div>
  );
};

export default Logo;