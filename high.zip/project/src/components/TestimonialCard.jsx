import React from 'react';
import { motion } from 'framer-motion';

const TestimonialCard = ({ quote, name, position, company, imageUrl }) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="frosted-glass p-6 rounded-xl mx-4 h-full flex flex-col"
    >
      <div className="flex-1">
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-4 opacity-70">
          <path d="M9.33333 20H12L10.6667 15.3333H13.3333V8H6V15.3333H8.66667L9.33333 20ZM20 20H22.6667L21.3333 15.3333H24V8H16.6667V15.3333H19.3333L20 20Z" fill="url(#quote-gradient)" />
          <defs>
            <linearGradient id="quote-gradient" x1="6" y1="14" x2="24" y2="14" gradientUnits="userSpaceOnUse">
              <stop stopColor="#00F5A0" />
              <stop offset="1" stopColor="#00D9F5" />
            </linearGradient>
          </defs>
        </svg>
        
        <p className="text-white/80 mb-6">{quote}</p>
      </div>
      
      <div className="flex items-center">
        <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#00F5A0] to-[#00D9F5] flex items-center justify-center overflow-hidden">
          {imageUrl ? (
            <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
          ) : (
            <span className="text-black font-bold text-lg">{name.charAt(0)}</span>
          )}
        </div>
        
        <div className="ml-3">
          <p className="font-medium">{name}</p>
          <p className="text-sm text-white/60">{position}, {company}</p>
        </div>
      </div>
    </motion.div>
  );
};

export default TestimonialCard;