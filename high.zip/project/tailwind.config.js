/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary-green': '#00F5A0',
        'primary-teal': '#00D9F5',
        'dark-bg': '#0A0A0A',
        'card-bg': 'rgba(30, 30, 30, 0.5)',
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'float-slow': 'float 8s ease-in-out infinite',
        'pulse-slow': 'pulse 4s ease-in-out infinite',
      },
      boxShadow: {
        'glow': '0 0 15px rgba(0, 245, 160, 0.5)',
      },
    },
  },
  plugins: [],
}