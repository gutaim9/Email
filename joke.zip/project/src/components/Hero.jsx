import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import ParticleBackground from './ParticleBackground';

const Hero = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const parallaxRef1 = useRef(null);
  const parallaxRef2 = useRef(null);
  const parallaxRef3 = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!parallaxRef1.current || !parallaxRef2.current || !parallaxRef3.current) return;
      
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      
      parallaxRef1.current.style.transform = `translate(${x * 30}px, ${y * 30}px)`;
      parallaxRef2.current.style.transform = `translate(${x * -20}px, ${y * 20}px)`;
      parallaxRef3.current.style.transform = `translate(${x * 15}px, ${y * -15}px)`;
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <section className="relative min-h-screen pt-32 pb-20 overflow-hidden">
      <ParticleBackground count={70} speed={0.3} />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Automate Your Email Marketing With <span className="gradient-text">AI-Powered Precision</span>
            </h1>
            
            <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto lg:mx-0">
              Save 15+ hours weekly while delivering perfectly-timed, personalized email campaigns that convert.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <motion.a
                href="#trial"
                className="gradient-button text-lg px-8 py-4"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                Start Free Trial
              </motion.a>
              
              <motion.a
                href="#demo"
                className="border border-white/20 bg-white/5 hover:bg-white/10 transition-colors text-white text-lg px-8 py-4 rounded-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                See Demo
              </motion.a>
            </div>
          </motion.div>
          
          <div className="relative h-[400px] md:h-[500px]">
            <div className="absolute inset-0">
              {/* Email UI elements */}
              <motion.div
                ref={parallaxRef1}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="absolute top-0 right-0 w-64 h-48 frosted-glass p-4 rounded-lg shadow-lg"
                style={{ transform: 'rotate(5deg)' }}
              >
                <div className="w-full h-4 mb-3 bg-white/20 rounded-full"></div>
                <div className="w-3/4 h-3 mb-2 bg-white/20 rounded-full"></div>
                <div className="w-full h-3 mb-2 bg-white/20 rounded-full"></div>
                <div className="w-5/6 h-3 mb-2 bg-white/20 rounded-full"></div>
                <div className="mt-4 flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#00F5A0] to-[#00D9F5]"></div>
                  <div className="ml-2 w-20 h-3 bg-white/20 rounded-full"></div>
                </div>
              </motion.div>
              
              <motion.div
                ref={parallaxRef2}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="absolute top-1/4 left-0 w-72 h-64 frosted-glass p-4 rounded-lg shadow-lg animate-float"
                style={{ transform: 'rotate(-8deg)' }}
              >
                <div className="flex justify-between items-center mb-4">
                  <div className="w-32 h-4 bg-white/20 rounded-full"></div>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#00F5A0] to-[#00D9F5] flex items-center justify-center text-black font-bold">A</div>
                </div>
                <div className="w-full h-4 mb-3 bg-white/20 rounded-full"></div>
                <div className="w-4/5 h-3 mb-2 bg-white/20 rounded-full"></div>
                <div className="w-full h-3 mb-2 bg-white/20 rounded-full"></div>
                <div className="w-3/4 h-3 mb-4 bg-white/20 rounded-full"></div>
                <div className="w-1/2 h-8 rounded-md bg-gradient-to-r from-[#00F5A0] to-[#00D9F5] mx-auto"></div>
              </motion.div>
              
              <motion.div
                ref={parallaxRef3}
                initial={{ opacity: 0, y: 40 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.8 }}
                className="absolute bottom-0 right-1/4 w-56 h-52 frosted-glass p-4 rounded-lg shadow-lg animate-float-slow"
                style={{ transform: 'rotate(3deg)' }}
              >
                <div className="flex items-center mb-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#00F5A0] to-[#00D9F5]"></div>
                  <div className="ml-2 w-24 h-3 bg-white/20 rounded-full"></div>
                </div>
                <div className="w-full h-20 mb-3 rounded-md bg-white/10"></div>
                <div className="w-full flex justify-between">
                  <div className="w-20 h-6 rounded-md bg-white/20"></div>
                  <div className="w-20 h-6 rounded-md bg-gradient-to-r from-[#00F5A0] to-[#00D9F5]"></div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-16 text-center"
        >
          <p className="text-white/60 mb-6">Trusted by industry leaders</p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16">
            {['Adobe', 'Shopify', 'Slack', 'Dropbox', 'Notion'].map((company, index) => (
              <div key={index} className="logo-grayscale">
                <span className="text-xl font-semibold text-white/40">{company}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;